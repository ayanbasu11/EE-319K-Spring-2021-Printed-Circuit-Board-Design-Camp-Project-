# Element14 Eagle CAD Libraries

This is a dump of Element14's Eagle CAD libraries. Kept in a git repo for ease
of distribution and updates.

## Orgional zip files

The files orgionally came from [Element14's comunity](https://www.element14.com/community/community/cadsoft_eagle/eagle_cad_libraries).
